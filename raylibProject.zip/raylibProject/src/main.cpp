#include "game.hpp"

int main() {
    const int screenWidth = 650;
    const int screenHeight = 650;
    const int cellSize = 60;
    //defining colors that are going to be used throughout the whole game

    Jeu jeu(screenWidth, screenHeight, cellSize);
    jeu.boucle_principale();

    return 0;
}
