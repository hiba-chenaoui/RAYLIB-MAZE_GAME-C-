#include "player.hpp"
#include "raylib.h"

Player::Player(int startX, int startY):x(startX), y(startY) {
    texture = LoadTexture("player.png");
}

void Player::draw(int cellSize, int offsetX, int offsetY)
{
    // Draw player as a yellow ball
        float centerX = offsetX + x * cellSize + cellSize / 2;
        float centerY = offsetY + y * cellSize + cellSize / 2;
        Rectangle source = {0.0f, 0.0f, (float)texture.width, (float)texture.height};  // Partie entière de l'image
        Rectangle dest = {centerX, centerY, 20, 20};  // Taille redimensionnée
        Vector2 origin = {20 / 2, 20 / 2}; // Pas de rotation ici
        DrawCircle(centerX, centerY, 15, LIGHT_PINK);
        DrawTexturePro(texture, source, dest, origin, 0.0f, WHITE);
}

void Player::move(const Maze &maze, int key)
{
    if (key == KEY_UP && !maze.hasWall(x, y, 0)) y--;       // Move up
    if (key == KEY_RIGHT && !maze.hasWall(x, y, 1)) x++;    // Move right
    if (key == KEY_DOWN && !maze.hasWall(x, y, 2)) y++;     // Move down
    if (key == KEY_LEFT && !maze.hasWall(x, y, 3)) x--;     // Move left
}
Player::~Player(){
        UnloadTexture(texture);
    }