#include "game.hpp"

// Constructeur
Jeu::Jeu(int width, int height, int cellSize)
    : maze((width / cellSize) - 2, (height / cellSize) - 2, cellSize, cellSize, cellSize),
      player(0, ((height / cellSize) - 2) / 2), // Placement du joueur au centre gauche
      screenWidth(width), screenHeight(height), cellSize(cellSize),
      offsetX(cellSize), offsetY(cellSize),
      etat_jeu(START), haswon(false), partie_active(false), chronometre(0), transitionframes(0), countdown(3) {
    font1 = LoadFontEx("../fonts/font1.ttf", 64, 0, 0);
    levels = {
    {{230, 190, 180, 60}, "level 1"}, 
    {{230, 290, 180, 60}, "level 2"}, 
    {{230, 390, 180, 60}, "level 3"}  
    };
   }

// Méthode pour gérer les événements
void Jeu::gerer_evenements() {
    if (etat_jeu == START) {
        //premiere interface utilisateur
        Vector2 mouseposition = GetMousePosition();
        Rectangle StartButton = {190, 320, 280, 90};
        DrawRectangleRounded(StartButton, 0.4, 6, LIGHT_PINK);
        DrawTextEx(font1, "Start", {250, 340}, 60, 2, PEACH_PUFF);
        if (CheckCollisionPointRec(mouseposition, StartButton)) {
            DrawRectangleRoundedLines(StartButton, 0.4, 6, 2, HOT_PINK);
            if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
                etat_jeu = MENU;
            }
        }

    } else if (etat_jeu == MENU) {
        drawmenu();

    } else if (etat_jeu == TRANSITION) {
        preparetoi();

    } else if (etat_jeu == EN_COURS) {
        //home and reply button creation end event detection
        Vector2 mouseposition = GetMousePosition();
        // Home Button (Bottom Left Corner) 
        Rectangle HomeButton = {30, screenHeight - 70, 180, 50}; // Bottom left
        DrawRectangleRounded(HomeButton, 0.4, 6, LIGHT_PINK);
        DrawTextEx(font1, "Home", {HomeButton.x + 40, HomeButton.y + 10}, 28, 2, PEACH_PUFF);

        if (CheckCollisionPointRec(mouseposition, HomeButton)) {
            DrawRectangleRoundedLines(HomeButton, 0.4, 6, 2, HOT_PINK);
            if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
                etat_jeu = MENU; // Return to main menu
            }
        }
        // Replay Button (Bottom Right Corner)
        Rectangle ReplayButton = {screenWidth - 210, screenHeight - 70, 180, 50}; // Bottom right
        DrawRectangleRounded(ReplayButton, 0.4, 6, LIGHT_PINK);
        DrawTextEx(font1, "Replay", {ReplayButton.x + 30, ReplayButton.y + 10}, 28, 2, PEACH_PUFF);
        if (CheckCollisionPointRec(mouseposition, ReplayButton)) {
            DrawRectangleRoundedLines(ReplayButton, 0.4, 6, 2, HOT_PINK);
            if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
                reinitialiser_partie(); // Restart the game
            }
        }

        //  Timer Display (Bottom Center) 
        const char *timerText = TextFormat("Time: %.2f seconds", chronometre);
        int textWidth = MeasureText(timerText, 20); // Measure text width
        int textX = (screenWidth / 2) - (textWidth / 2); // Center horizontally
        int textY = screenHeight - 50; // 50 pixels from the bottom
        DrawText(timerText, textX, textY, 20, LIGHT_PINK);

        chronometre += GetFrameTime(); // Update the timer

        // Handle keyboard input
    
        if (IsKeyPressed(KEY_UP) || IsKeyPressed(KEY_RIGHT) ||
                   IsKeyPressed(KEY_DOWN) || IsKeyPressed(KEY_LEFT)) {
            player.move(maze, GetKeyPressed());
            verifierVictoire();
        }
    } else if (etat_jeu == FIN) {
        // Display the final time when the player finishes the maze
        const char *finalTimeText = TextFormat("Your time is: %.2f seconds", chronometre);
        int textWidth = MeasureText(finalTimeText, 40);
        int textX = (screenWidth / 2) - (textWidth / 2);
        int textY = screenHeight / 2 + 50; // Position below the victory text
        
        DrawTextEx(font1, "You won!", {170, 280}, 90, 2, LIGHT_PINK);
        DrawText(finalTimeText, textX, textY, 40, WHITE);
        replay();
    }
}



// Vérifier si le joueur a atteint la fin
void Jeu::verifierVictoire() {
    if (player.x == ((screenWidth / cellSize) - 2) && player.y == ((screenHeight / cellSize) - 2) / 2) {
        haswon = true;
        etat_jeu = FIN;
        countdown = 3;
    }
}

void Jeu::drawmenu() {
    Vector2 mouseposition = GetMousePosition();
    Color btncolor = LIGHT_PINK;

    for (size_t i = 0; i < levels.size(); i++) {
        DrawRectangleRounded(levels[i].rect, 0.4, 6, btncolor);
        DrawTextEx(font1, levels[i].text.c_str(), {levels[i].rect.x + 40, levels[i].rect.y + 20}, 28, 2, PEACH_PUFF);

        if (CheckCollisionPointRec(mouseposition, levels[i].rect)) {
            DrawRectangleRoundedLines(levels[i].rect, 0.4, 6, 2, HOT_PINK);
            if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
                etat_jeu = TRANSITION;
                transitionframes = 0;
                if (i == 0) cellSize=60;
                else if (i == 1) cellSize=40;
                else cellSize=30 ;
            }
        }
    }
}

void Jeu::preparetoi() {
    DrawTextEx(font1, "Get Ready !", {180, 350}, 55, 2, LIGHT_PINK);
    DrawText(TextFormat("%d", countdown), screenWidth / 2 - 15, 240, 80, LIGHT_PINK);

    transitionframes++;
    if (transitionframes % framestowait == 0) {
        countdown--;
    }
    if (countdown <= 0) {
        etat_jeu = EN_COURS;
        demarrer_partie();
        chronometre = 0;
    }
}

// Méthode pour démarrer une nouvelle partie
void Jeu::demarrer_partie() {
    partie_active = true;
    int mazeHeight = ((screenHeight / cellSize) - 2) * cellSize;
    int bottomMargin = 80; // Espace pour les boutons
    offsetY = (screenHeight - mazeHeight - bottomMargin) / 2;
    maze = Maze((screenWidth / cellSize) - 2, (screenHeight / cellSize) - 2, cellSize, offsetX, offsetY);
    player = Player(0, ((screenHeight / cellSize) - 2) / 2);

    DrawText(TextFormat("Temps : %.2f secondes", chronometre), 10, 10, 20, BLACK);
}

// Méthode pour réinitialiser la partie
void Jeu::reinitialiser_partie() {
    demarrer_partie();
}

void Jeu::replay() {
    Vector2 mouseposition = GetMousePosition();
    endoptions = {
        {{30, 430, 180, 60}, " Home"},
        {{220, 430, 180, 60}, "Restart"},
        {{410, 430, 180, 60}, "  Quit"},
    };

    for (size_t i = 0; i < endoptions.size(); i++) {
        DrawRectangleRounded(endoptions[i].rect, 0.4, 6, LIGHT_PINK);
        DrawTextEx(font1, endoptions[i].text.c_str(), {endoptions[i].rect.x + 40, endoptions[i].rect.y + 20}, 28, 2, PEACH_PUFF);

        if (CheckCollisionPointRec(mouseposition, endoptions[i].rect)) {
            DrawRectangleRoundedLines(endoptions[i].rect, 0.4, 6, 2, HOT_PINK);
            if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
                if (i == 0) etat_jeu = MENU;
                else if (i == 1) etat_jeu = TRANSITION;
                else CloseWindow();
            }
        }
    }
}

// Boucle principale du jeu
void Jeu::boucle_principale() {
    InitWindow(screenWidth, screenHeight, "Maze Game with Player");
    SetTargetFPS(60);
    Texture2D texture = LoadTexture("../graphics/rubbit.png");
    InitAudioDevice(); 

    while (!WindowShouldClose()) {
        ClearBackground(PEACH_PUFF);
        gerer_evenements();

        if (etat_jeu == EN_COURS) {
            chronometre += GetFrameTime();
            
            maze.draw();
            player.draw(cellSize, offsetX, offsetY);
            DrawTexture(texture, 100, 100, WHITE);
        }

        EndDrawing();
    }
    UnloadTexture(texture);
    CloseWindow();
}