#ifndef GAME_HPP
#define GAME_HPP

#include "raylib.h"
#include "maze.hpp"
#include "player.hpp"
#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct options{
    Rectangle rect;
    string text;
};

class Jeu {
private:
    Maze maze;           // Objet représentant le labyrinthe
    Player player;       // Objet représentant le joueur
    int screenWidth;     // Largeur de l'écran
    int screenHeight;    // Hauteur de l'écran
    int cellSize;        // Taille des cellules du labyrinthe
    int offsetX;         // Décalage horizontal
    int offsetY;         // Décalage vertical
    Font font1;
    Texture2D texture;
    enum Etat { START ,MENU, TRANSITION, EN_COURS, FIN } etat_jeu; // États du jeu


    bool partie_active;  // Indique si une partie est en cours
    bool haswon;
    int transitionframes;
    static const int framestowait=60;
    int countdown;
    float chronometre;   // Chronomètre en secondes
    
    vector<options>levels;
    vector<options>endoptions;
    const Color LIGHT_PINK = (Color){255, 100, 150, 255}; // Light Pink
    const Color HOT_PINK = (Color){255, 105, 180, 255};   // Hot Pink
    const Color DEEP_PINK = (Color){255, 20, 147, 255};   // Deep Pink
    const Color PEACH_PUFF = (Color){255, 218, 185, 255}; // Peach Puff

    void gerer_evenements();
    void verifierVictoire();
    void drawmenu();               //afficher le menu
    void preparetoi();
    void replay();

public:
    Jeu(int width, int height, int cellSize); // Constructeur

    void demarrer_partie();        // Démarrer une nouvelle partie
    void reinitialiser_partie();   // Réinitialiser la partie
    void boucle_principale();      // Boucle principale du jeu
    
};

#endif // GAME_HPP
