#ifndef MAZE_HPP
#define MAZE_HPP
#include<raylib.h>
#include <vector>
#include <stack>


class Cell{
    public:
    int x, y;
    bool visited;
    bool walls[4]; // Top, Right, Bottom, Left
    Cell(int x, int y);
    };
    
class Maze{
  private :
    int width, height;
    int cellSize;
    int offsetX, offsetY;
    std::vector<std::vector<Cell>> grid;
    std::stack<Cell*> cellStack;

    Cell*  getRandomNeighbor(Cell* cell);

    void removeWalls(Cell* a, Cell* b);

    void drawCell(const Cell& cell) const;

public:
    Maze(int width, int height, int cellSize, int offsetX, int offsetY);

    void generateMaze(Cell* start);

    void draw() const;

    bool hasWall(int x,int y,int direction) const;


};
#endif
