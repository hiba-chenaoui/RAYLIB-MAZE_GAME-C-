#include "player.hpp"
#include "raylib.h"

Player::Player(int startX, int startY):x(startX), y(startY) {
     texture = LoadTexture("../graphics/rubbit.png");
}

void Player::draw(int cellSize, int offsetX, int offsetY)
{
    
        float centerX = offsetX + x * cellSize + cellSize / 2;
        float centerY = offsetY + y * cellSize + cellSize / 2;
        /*Rectangle source = {0.0f, 0.0f, (float)texture.width, (float)texture.height};  // Partie entière de l'image
        Rectangle dest = {
        (float)(centerX - cellSize / 2), // Top-left corner X
        (float)(centerY - cellSize / 2), // Top-left corner Y
        (float)cellSize,                 // Width scaled to cell size
        (float)cellSize                  // Height scaled to cell size
        };
        Vector2 origin = {dest.width / 2, dest.height / 2};
        DrawTexturePro(texture, source, dest, origin, 0.0f, WHITE);
        */
        // Draw player as a pink ball
        DrawCircle(centerX, centerY, 15, LIGHT_PINK);
        
}

void Player::move(const Maze &maze, int key)
{
//Check which key is pressed and check if the destined cell is not a wall before moving the player
    if (key == KEY_UP && !maze.hasWall(x, y, 0)) y--;       // Move up
    if (key == KEY_RIGHT && !maze.hasWall(x, y, 1)) x++;    // Move right
    if (key == KEY_DOWN && !maze.hasWall(x, y, 2)) y++;     // Move down
    if (key == KEY_LEFT && !maze.hasWall(x, y, 3)) x--;     // Move left
}
Player::~Player(){
        UnloadTexture(texture);
    }