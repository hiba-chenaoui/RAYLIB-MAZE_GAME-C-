#ifndef MAZE_HPP
#define MAZE_HPP
#include<raylib.h>
#include <vector>
#include <stack>

// a cell class that will present the cells of our grid
class Cell{
    public:
    int x, y;
    bool visited;
    bool walls[4]; // representing the walls of each cell [0]Top, [1]Right, [2]Bottom,[3]Left
    Cell(int x, int y);
    };
    
class Maze{
  private :
    int width, height;
    int cellSize;
    int offsetX, offsetY;
    std::vector<std::vector<Cell>> grid;
    //a stack to save each visited cell
    std::stack<Cell*> cellStack; 

    Cell*  getRandomNeighbor(Cell* cell); 

    void removeWalls(Cell* a, Cell* b);

    void drawCell(const Cell& cell) const;

public:
    Maze(int width, int height, int cellSize, int offsetX, int offsetY);

    void generateMaze(Cell* start);

    void draw() const;

    bool hasWall(int x,int y,int direction) const;

};
#endif
