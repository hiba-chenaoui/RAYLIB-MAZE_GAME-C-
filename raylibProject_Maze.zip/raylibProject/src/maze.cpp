#include "maze.hpp"
#include<iostream>


Cell::Cell(int x, int y): x(x), y(y), visited(false) {
        //creating the grid with all 4 walls peresent
        walls[0] = walls[1] = walls[2] = walls[3] = true;
    };

Maze::Maze(int width, int height, int cellSize, int offsetX, int offsetY)
    : width(width), height(height), cellSize(cellSize), offsetX(offsetX), offsetY(offsetY) {
        for (int y = 0; y < height; y++) {
            std::vector<Cell> row;  //vector to represent esch row of the grid
            for (int x = 0; x < width; x++) {
                row.emplace_back(x, y);  //adding the cells to the row 
            }
            grid.push_back(row); //adding the row to the grid each row is a vector of cells 
        }

        // Open the middle of the left and right borders to create the start in the end of the maze 
        int middleRow = height / 2;
        grid[middleRow][0].walls[3] = false;            // Remove left wall
        grid[middleRow][width - 1].walls[1] = false;    // Remove right wall

        srand(time(0)); //will bw used to produce a random integer
        generateMaze(&grid[0][0]); // the function that will generate our maze
    }

    void Maze::generateMaze(Cell *start)
    {
        start->visited = true; //setting the start point for DFS algorithm
        cellStack.push(start);  //adding the cell "start" to the stack since we visited it

        //repeating steps as long as we didn't visit all the cells 
        while (!cellStack.empty()) {
            Cell* current = cellStack.top();
            Cell* next = getRandomNeighbor(current);//to choose the next cell to be visited randomly 

            //check if the current cell has a non visited neighbor
            if (next != nullptr) {
                next->visited = true; //marking the randomly chosen neighbor cell as visited
                removeWalls(current, next); //removing the wall between the current and the neighbor visited cell
                cellStack.push(next);   //adding the newely visited cell to the stack as the last visited cell
            } else {
                //Moving backward since there is no invisited neighbor 
                cellStack.pop();  
            }
            //if the stack is not empty after pop than we repeat the steps 
        }
    }

    void Maze::draw() const
    {
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                drawCell(grid[y][x]);
            }
        }
    }

    bool Maze::hasWall(int x, int y, int direction) const
    {
        // Check for walls in the specified direction (0=Top, 1=Right, 2=Bottom, 3=Left)
        if (x < 0 || x >= width || y < 0 || y >= height) return true; 
        return grid[y][x].walls[direction];
        
    }

Cell *Maze::getRandomNeighbor(Cell *cell)
{
    std::vector<Cell*> neighbors; //a vector that will save all the invisited neighbor cells of a given cell

        //x and y coordinates of the current cell
        int x = cell->x;
        int y = cell->y;

        //check the position of the current cell and based on its position check if its neighbor cell was visited
        if (y > 0 && !grid[y - 1][x].visited) neighbors.push_back(&grid[y - 1][x]); // Top
        if (x < width - 1 && !grid[y][x + 1].visited) neighbors.push_back(&grid[y][x + 1]); // Right
        if (y < height - 1 && !grid[y + 1][x].visited) neighbors.push_back(&grid[y + 1][x]); // Bottom
        if (x > 0 && !grid[y][x - 1].visited) neighbors.push_back(&grid[y][x - 1]); // Left

        //if the cell has some invisted neighbors we will return one of the neighbors randomly
        if (!neighbors.empty()) {
            int randIndex = rand() % neighbors.size();
            return neighbors[randIndex];
        }
        //if the cell has no invisited neighbors retun nullptr 
        return nullptr;
}

void Maze::removeWalls(Cell *a, Cell *b)
{
    int dx = a->x - b->x;
        int dy = a->y - b->y;

        if (dx == 1) { // a is to the right of b
            a->walls[3] = false;
            b->walls[1] = false;
        } else if (dx == -1) { // a is to the left of b
            a->walls[1] = false;
            b->walls[3] = false;
        }
        if (dy == 1) { // a is below b
            a->walls[0] = false;
            b->walls[2] = false;
        } else if (dy == -1) { // a is above b
            a->walls[2] = false;
            b->walls[0] = false;
        }
}

void Maze::drawCell(const Cell &cell) const
{
    int x = offsetX + cell.x * cellSize;
        int y = offsetY + cell.y * cellSize;
        int thickness = 3;

        const Color DEEP_PINK = (Color){255, 100, 150, 255};

        // Draw walls
        if (cell.walls[0]) DrawRectangle(x, y - thickness / 2, cellSize, thickness, DEEP_PINK);            // Top
        if (cell.walls[1]) DrawRectangle(x + cellSize - thickness / 2, y, thickness, cellSize, DEEP_PINK); // Right
        if (cell.walls[2]) DrawRectangle(x, y + cellSize - thickness / 2, cellSize, thickness, DEEP_PINK); // Bottom
        if (cell.walls[3]) DrawRectangle(x - thickness / 2, y, thickness, cellSize, DEEP_PINK);            // Left
    
}
