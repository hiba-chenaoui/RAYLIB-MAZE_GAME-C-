#include<raylib.h>
#include "maze.hpp"
const Color LIGHT_PINK = (Color){255, 182, 193, 255};
class Player{
public :

    int x,y;
    Texture2D texture;
    bool haswon;
    Player(int startX, int startY);
    void draw(int cellSize, int offsetX, int offsetY);
    void move(const Maze& maze, int key);
    ~Player();
    
};