#include "game.hpp"

int main() {
    const int screenWidth = 650; 
    const int screenHeight = 650;
    const int cellSize = 60;
    
    Jeu jeu(screenWidth, screenHeight, cellSize);
    jeu.boucle_principale();

    return 0;
}
