#ifndef GAME_HPP
#define GAME_HPP

#include "raylib.h"
#include "maze.hpp"
#include "player.hpp"
#include <iostream>
#include <vector>
#include <string>

using namespace std;
//define our button as a type(rectangle and its text)
struct options{
    Rectangle rect;
    string text;
};

class Jeu {
private:
    Maze maze;           // Object of class maze 
    Player player;       // Object representing the player
    int screenWidth;     // Largeur de l'écran
    int screenHeight;    // Hauteur de l'écran
    int cellSize;        // Taille des cellules du labyrinthe
    int offsetX;         // Décalage horizontal
    int offsetY;         // Décalage vertical
    Font font1;
    enum Etat { START ,MENU, TRANSITION, EN_COURS, FIN } etat_jeu; //storing diffrent game states


    bool partie_active;  // Indique si une partie est en cours
    bool haswon;   //determine if the player has arrived to the end of maze
    int transitionframes;  //To track the number of frames have passed 
    static const int framestowait=60;
    int countdown;   //Create a countdown before the game starts 
    float chronometre;   // Chronomètre en secondes
    
    vector<options>levels;
    vector<options>endoptions;
    //the colors needed for the drawing 
    const Color LIGHT_PINK = (Color){255, 100, 150, 255}; // Light Pink
    const Color HOT_PINK = (Color){255, 105, 180, 255};   // Hot Pink
    const Color DEEP_PINK = (Color){255, 20, 147, 255};   // Deep Pink
    const Color PEACH_PUFF = (Color){255, 218, 185, 255}; // Peach Puff

    void gerer_evenements(); //gére les differents etats du jeu 
    void verifierVictoire(); //check if the player arrived to the end 
    void drawmenu();       //draw the menu of our game
    void preparetoi();     //shows a message to tell the user to get ready
    void replay();   //used to turn the player to the starting point and creating a new maze

public:
    Jeu(int width, int height, int cellSize); // Constructeur

    void demarrer_partie();        // Démarrer une nouvelle partie
    void reinitialiser_partie();   // Réinitialiser la partie
    void boucle_principale();      // Boucle principale du jeu
    
};

#endif // GAME_HPP
